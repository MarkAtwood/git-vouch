# did_verify.py
import os
import json
from pathlib import Path
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import ed25519
from cryptography.exceptions import InvalidSignature

def load_json(path):
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def verify_signature(doc, public_key):
    try:
        sig = bytes.fromhex(doc['proof']['signature'])
        message = json.dumps(doc['credential'], sort_keys=True).encode('utf-8')
        public_key.verify(sig, message)
        return True
    except InvalidSignature:
        return False

def get_public_key_from_did(did_path):
    doc = load_json(did_path)
    key_b64 = doc['publicKey'][0]['publicKeyBase58']
    key_bytes = bytes.fromhex(key_b64)
    return ed25519.Ed25519PublicKey.from_public_bytes(key_bytes)

def is_revoked(issuer_path, cred_id):
    revoked_path = issuer_path / 'revoked' / f'{cred_id}.json'
    if not revoked_path.exists():
        return False
    try:
        rev_doc = load_json(revoked_path)
        pubkey = get_public_key_from_did(issuer_path / 'dids' / 'main.jsonld')
        sig = bytes.fromhex(rev_doc['proof']['signature'])
        message = json.dumps({k: v for k, v in rev_doc.items() if k != 'proof'}, sort_keys=True).encode('utf-8')
        pubkey.verify(sig, message)
        return True
    except Exception:
        return False

def verify_all(base_path):
    for root, dirs, files in os.walk(base_path):
        for file in files:
            if file.endswith('.json') or file.endswith('.jsonld'):
                path = Path(root) / file
                try:
                    doc = load_json(path)
                    cred_id = doc['credential']['id'].split(':')[-1]
                    issuer_did = doc['issuer']
                    issuer_path = base_path / Path(issuer_did.replace(':', '/')[1:])
                    did_path = issuer_path / 'dids' / 'main.jsonld'
                    pubkey = get_public_key_from_did(did_path)
                    if is_revoked(issuer_path, cred_id):
                        print(f"✗ Revoked: {path}")
                    elif verify_signature(doc, pubkey):
                        print(f"✓ Verified: {path}")
                    else:
                        print(f"✗ Invalid signature: {path}")
                except Exception as e:
                    print(f"⚠ Error processing {path}: {e}")

if __name__ == '__main__':
    import sys
    base = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('trusts')
    verify_all(base)
